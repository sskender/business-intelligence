1. Prvo je potrebno kreirati bazu
2. Pokrenuti skripte dDate.sql i dTimeOfDay.sql
3. Pokrenuti skriptu createWarehouse.sql
4. Pokrenuti skriptu importData.sql